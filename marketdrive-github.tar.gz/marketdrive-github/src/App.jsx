import { useState } from 'react'
import { Shield, MapPin, Calendar, Lock, Truck, FileText } from 'lucide-react'

const BANKING_DETAILS = {
  bank: "Capitec Bank",
  accountNumber: "1662785710",
  accountHolder: "MARKETDRIVE PTY LTD"
}

const BRANDS = ['BMW', 'Mercedes-Benz', 'Toyota', 'Tesla', 'Audi', 'Porsche', 'Ford', 'Honda']

const DEMO_LISTINGS = [
  { id: 1, title: '2023 BMW M5 Competition', brand: 'BMW', year: 2023, price: 1850000, currency: 'R', city: 'Cape Town', country: 'South Africa', mileage: 8500, image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800', verified: true, seller: 'John Motors', sellerVerified: true },
  { id: 2, title: '2024 Tesla Model S Plaid', brand: 'Tesla', year: 2024, price: 95000, currency: '$', city: 'Los Angeles', country: 'USA', mileage: 1200, image: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800', verified: true, seller: 'Tesla Direct', sellerVerified: true },
  { id: 3, title: '2023 Mercedes-AMG GT', brand: 'Mercedes-Benz', year: 2023, price: 98000, currency: '£', city: 'London', country: 'UK', mileage: 5600, image: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800', verified: true, seller: 'UK Motors', sellerVerified: true },
  { id: 4, title: '2024 Audi e-tron GT', brand: 'Audi', year: 2024, price: 785000, currency: 'R', city: 'Johannesburg', country: 'South Africa', mileage: 2100, image: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f8172?w=800', verified: true, seller: 'Elite Autos', sellerVerified: true },
]

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [user, setUser] = useState(null)
  const [showLogin, setShowLogin] = useState(false)
  const [showPayment, setShowPayment] = useState(false)
  const [showTracking, setShowTracking] = useState(false)
  const [showPostListing, setShowPostListing] = useState(false)
  const [selectedListing, setSelectedListing] = useState(null)
  const [selectedBrand, setSelectedBrand] = useState('')
  const [trackingStatus, setTrackingStatus] = useState('in_escrow')

  const handleLogin = () => {
    setUser({ name: 'John Doe', email: 'user@example.com', verified: true, id: 'USER12345' })
    setIsLoggedIn(true)
    setShowLogin(false)
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setUser(null)
  }

  const handlePurchase = () => {
    setShowPayment(false)
    setTrackingStatus('in_escrow')
    setShowTracking(true)
  }

  const filteredListings = selectedBrand 
    ? DEMO_LISTINGS.filter(l => l.brand === selectedBrand) 
    : DEMO_LISTINGS

  return (
    <div style={{ minHeight: '100vh', background: '#000' }}>
      {/* Header */}
      <header style={{ background: 'rgba(0,0,0,0.95)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(255,255,255,0.1)', position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto', padding: 'clamp(1rem, 3vw, 1.5rem)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'clamp(0.75rem, 2vw, 1rem)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{ width: 'clamp(40px, 8vw, 50px)', height: 'clamp(40px, 8vw, 50px)', borderRadius: '12px', background: 'linear-gradient(135deg, #1a73e8, #1557b0)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem', boxShadow: '0 4px 12px rgba(26,115,232,0.3)' }}>
                🚗
              </div>
              <span style={{ fontSize: 'clamp(1.2rem, 4vw, 1.5rem)', fontWeight: 900 }}>
                MARKET<span style={{ color: '#1a73e8' }}>DRIVE</span>
              </span>
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              {isLoggedIn ? (
                <>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem', background: 'rgba(52,168,83,0.2)', borderRadius: '50px' }}>
                    <Shield size={16} color="#34a853" />
                    <span style={{ color: '#34a853', fontWeight: 600, fontSize: 'clamp(0.85rem, 2.5vw, 0.9rem)' }}>Verified</span>
                  </div>
                  <button onClick={handleLogout} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', padding: 'clamp(0.6rem, 2vw, 0.75rem) clamp(1rem, 3vw, 1.5rem)', borderRadius: '50px', fontWeight: 600, cursor: 'pointer', fontSize: 'clamp(0.85rem, 2.5vw, 0.95rem)' }}>
                    Logout
                  </button>
                </>
              ) : (
                <button onClick={() => setShowLogin(true)} style={{ background: 'linear-gradient(135deg, #1a73e8, #1557b0)', color: '#fff', border: 'none', padding: 'clamp(0.6rem, 2vw, 0.75rem) clamp(1.2rem, 3vw, 1.75rem)', borderRadius: '50px', fontWeight: 700, cursor: 'pointer', fontSize: 'clamp(0.85rem, 2.5vw, 0.95rem)', boxShadow: '0 4px 12px rgba(26,115,232,0.3)' }}>
                  Login
                </button>
              )}
            </div>
          </div>
          
          <nav style={{ display: 'flex', gap: 'clamp(1rem, 3vw, 2rem)', alignItems: 'center', paddingTop: 'clamp(0.75rem, 2vw, 1rem)', borderTop: '1px solid rgba(255,255,255,0.1)', flexWrap: 'wrap' }}>
            <a href="#browse" style={{ color: '#fff', textDecoration: 'none', fontWeight: 600, fontSize: 'clamp(0.85rem, 2.5vw, 1rem)' }}>Browse</a>
            <a href="#sell" onClick={(e) => { e.preventDefault(); isLoggedIn && user?.verified ? setShowPostListing(true) : alert('Please login and verify first') }} style={{ color: '#fff', textDecoration: 'none', fontWeight: 600, fontSize: 'clamp(0.85rem, 2.5vw, 1rem)' }}>Sell</a>
            <a href="#verify" style={{ color: '#fff', textDecoration: 'none', fontWeight: 600, fontSize: 'clamp(0.85rem, 2.5vw, 1rem)' }}>Verification</a>
            <a href="#profile" style={{ color: '#fff', textDecoration: 'none', fontWeight: 600, fontSize: 'clamp(0.85rem, 2.5vw, 1rem)' }}>Profile</a>
            <button style={{ background: 'linear-gradient(135deg, #1a73e8, #1557b0)', color: '#fff', border: 'none', padding: 'clamp(0.6rem, 2vw, 0.75rem) clamp(1.2rem, 3vw, 1.75rem)', borderRadius: '50px', fontWeight: 700, cursor: 'pointer', marginLeft: 'auto', fontSize: 'clamp(0.85rem, 2.5vw, 0.95rem)' }}>
              Get Started
            </button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <div style={{ padding: 'clamp(2rem, 6vw, 4rem) clamp(1rem, 4vw, 2rem)', textAlign: 'center', background: 'linear-gradient(180deg, #000 0%, #0f0f0f 50%, #000 100%)', position: 'relative', overflow: 'hidden' }}>
        {/* Subtle Background */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'linear-gradient(135deg, rgba(26,115,232,0.05) 0%, rgba(234,67,53,0.05) 100%), url(https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=1600) center/cover', opacity: 0.12, filter: 'blur(1px)' }}></div>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'radial-gradient(circle at center, transparent 0%, rgba(0,0,0,0.7) 100%)' }}></div>
        
        <div style={{ position: 'relative', zIndex: 1, maxWidth: '1200px', margin: '0 auto' }}>
          {/* Badge */}
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(234,67,53,0.2)', border: '1px solid rgba(234,67,53,0.5)', padding: 'clamp(0.6rem, 2vw, 0.75rem) clamp(1.2rem, 3vw, 1.75rem)', borderRadius: '50px', marginBottom: 'clamp(1.5rem, 4vw, 2.5rem)' }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#ea4335', animation: 'pulse 2s infinite' }}></div>
            <span style={{ color: '#ea4335', fontWeight: 700, fontSize: 'clamp(0.85rem, 2.5vw, 1rem)' }}>The World's Vehicle Marketplace</span>
          </div>
          
          {/* Main Slogan */}
          <h1 style={{ fontSize: 'clamp(2.5rem, 12vw, 6rem)', fontWeight: 900, lineHeight: 0.95, marginBottom: 'clamp(0.5rem, 2vw, 1rem)', letterSpacing: '-2px', textShadow: '0 4px 20px rgba(0,0,0,0.5)' }}>
            DRIVE YOUR
          </h1>
          <h1 style={{ fontSize: 'clamp(2.5rem, 12vw, 6rem)', fontWeight: 900, lineHeight: 0.95, marginBottom: 'clamp(1.5rem, 4vw, 2rem)', letterSpacing: '-2px' }}>
            <span style={{ background: 'linear-gradient(135deg, #1a73e8 0%, #ea4335 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>DREAM</span>
          </h1>
          
          {/* Description */}
          <p style={{ fontSize: 'clamp(0.95rem, 3vw, 1.3rem)', color: '#bbb', maxWidth: '900px', margin: '0 auto clamp(2rem, 5vw, 3rem)', lineHeight: 1.6, padding: '0 1rem', textShadow: '0 2px 10px rgba(0,0,0,0.8)' }}>
            Buy and sell vehicles globally. Verified sellers, live video inspections, and secure transactions across 100+ countries.
          </p>
          
          {/* Search Bar */}
          <div style={{ maxWidth: '750px', margin: '0 auto clamp(2rem, 5vw, 3rem)', background: 'rgba(255,255,255,0.08)', backdropFilter: 'blur(20px)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '20px', padding: '0.5rem', boxShadow: '0 8px 32px rgba(0,0,0,0.3)' }}>
            <input type="text" placeholder="Search by brand, model, or location..." style={{ width: '100%', background: 'transparent', border: 'none', color: '#fff', padding: '1rem', fontSize: 'clamp(0.9rem, 2.5vw, 1rem)', outline: 'none' }} />
            <button style={{ background: 'linear-gradient(135deg, #ea4335, #c5221f)', color: '#fff', border: 'none', padding: 'clamp(0.9rem, 2.5vw, 1.1rem) clamp(2rem, 5vw, 3rem)', borderRadius: '15px', fontWeight: 700, fontSize: 'clamp(0.9rem, 2.5vw, 1.05rem)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', width: '100%', marginTop: '0.5rem', boxShadow: '0 4px 12px rgba(234,67,53,0.3)' }}>
              Search →
            </button>
          </div>
          
          {/* Brand Chips */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'clamp(0.75rem, 2vw, 1rem)', justifyContent: 'center' }}>
            {BRANDS.map(brand => (
              <button 
                key={brand} 
                onClick={() => { setSelectedBrand(brand === selectedBrand ? '' : brand); setTimeout(() => window.scrollTo({ top: 800, behavior: 'smooth' }), 100) }}
                style={{ 
                  background: selectedBrand === brand ? 'linear-gradient(135deg, #1a73e8, #1557b0)' : 'rgba(255,255,255,0.08)', 
                  backdropFilter: 'blur(10px)',
                  border: selectedBrand === brand ? '2px solid #1a73e8' : '1px solid rgba(255,255,255,0.2)', 
                  color: '#fff', 
                  padding: 'clamp(0.75rem, 2vw, 1rem) clamp(1.25rem, 3vw, 2rem)', 
                  borderRadius: '50px', 
                  fontWeight: 600, 
                  fontSize: 'clamp(0.8rem, 2.5vw, 0.95rem)', 
                  cursor: 'pointer',
                  boxShadow: selectedBrand === brand ? '0 4px 16px rgba(26,115,232,0.4)' : 'none'
                }}
              >
                {brand}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div style={{ padding: 'clamp(3rem, 8vw, 5rem) clamp(1rem, 4vw, 2rem)', background: 'linear-gradient(180deg, #000 0%, #0a0a0a 100%)', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 'clamp(2rem, 5vw, 4rem)' }}>
          {[
            { number: '100+', label: 'Countries', color: '#1a73e8' },
            { number: '50K+', label: 'Vehicles Listed', color: '#ea4335' },
            { number: '10K+', label: 'Verified Sellers', color: '#34a853' },
            { number: '99%', label: 'Satisfaction Rate', color: '#f9ab00' }
          ].map((stat, i) => (
            <div key={i} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 'clamp(2.5rem, 10vw, 5rem)', fontWeight: 900, lineHeight: 1, marginBottom: 'clamp(0.5rem, 2vw, 1rem)', background: `linear-gradient(135deg, ${stat.color}, ${stat.color}cc)`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                {stat.number}
              </div>
              <div style={{ fontSize: 'clamp(0.85rem, 2.5vw, 1.05rem)', color: '#888', fontWeight: 500 }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Listings Section */}
      <div style={{ padding: 'clamp(3rem, 8vw, 5rem) clamp(1rem, 4vw, 2rem)', background: 'linear-gradient(180deg, #0a0a0a 0%, #000 100%)' }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
          <h2 style={{ fontSize: 'clamp(1.8rem, 6vw, 3rem)', fontWeight: 900, marginBottom: 'clamp(2rem, 5vw, 3rem)' }}>
            {selectedBrand ? `${selectedBrand} Vehicles` : 'Featured Listings'}
          </h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 350px), 1fr))', gap: 'clamp(1.5rem, 4vw, 2.5rem)' }}>
            {filteredListings.map(listing => (
              <div 
                key={listing.id} 
                style={{ 
                  background: 'linear-gradient(135deg, #0d0d0d, #1a1a1a)', 
                  border: '1px solid rgba(255,255,255,0.1)', 
                  borderRadius: '20px', 
                  overflow: 'hidden',
                  cursor: 'pointer',
                  transition: 'all 0.3s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.transform = 'translateY(-8px)'
                  e.currentTarget.style.borderColor = '#1a73e8'
                  e.currentTarget.style.boxShadow = '0 20px 50px rgba(26,115,232,0.25)'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)'
                  e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'
                  e.currentTarget.style.boxShadow = 'none'
                }}
              >
                <img src={listing.image} alt={listing.title} style={{ width: '100%', height: '220px', objectFit: 'cover' }} />
                <div style={{ padding: 'clamp(1.25rem, 3vw, 2rem)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 'clamp(0.75rem, 2vw, 1rem)' }}>
                    <h3 style={{ fontSize: 'clamp(1.1rem, 3vw, 1.3rem)', fontWeight: 700, lineHeight: 1.3 }}>{listing.title}</h3>
                    {listing.sellerVerified && (
                      <div style={{ background: 'linear-gradient(135deg, #34a853, #2d8e47)', padding: '0.5rem', borderRadius: '50%', flexShrink: 0 }}>
                        <Shield size={16} color="#fff" />
                      </div>
                    )}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: 'clamp(1rem, 3vw, 1.5rem)', color: '#aaa', fontSize: 'clamp(0.85rem, 2.5vw, 0.95rem)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <MapPin size={16} /> {listing.city}, {listing.country}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Calendar size={16} /> {listing.year} • {listing.mileage.toLocaleString()} km
                    </div>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 'clamp(0.75rem, 2vw, 1rem)', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                    <div style={{ fontSize: 'clamp(1.5rem, 5vw, 2rem)', fontWeight: 900, background: 'linear-gradient(135deg, #1a73e8, #1557b0)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                      {listing.currency}{listing.price.toLocaleString()}
                    </div>
                    <button 
                      onClick={() => { 
                        if (!isLoggedIn) { alert('Please login first'); setShowLogin(true); return }
                        if (!user?.verified) { alert('Please verify your account first'); return }
                        setSelectedListing(listing)
                        setShowPayment(true)
                      }} 
                      style={{ 
                        background: 'linear-gradient(135deg, #ea4335, #c5221f)', 
                        color: '#fff', 
                        border: 'none', 
                        padding: 'clamp(0.65rem, 2vw, 0.9rem) clamp(1rem, 3vw, 1.5rem)', 
                        borderRadius: '12px', 
                        fontWeight: 700, 
                        fontSize: 'clamp(0.8rem, 2.5vw, 0.95rem)', 
                        cursor: 'pointer',
                        boxShadow: '0 4px 16px rgba(234,67,53,0.3)'
                      }}
                    >
                      Buy Now
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Login Modal */}
      {showLogin && (
        <div onClick={() => setShowLogin(false)} style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.95)', backdropFilter: 'blur(10px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: 'linear-gradient(135deg, #0d0d0d, #1a1a1a)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', padding: '2rem', maxWidth: '500px', width: '100%', boxShadow: '0 20px 60px rgba(0,0,0,0.5)' }}>
            <h2 style={{ marginBottom: '2rem', color: '#1a73e8', fontSize: 'clamp(1.5rem, 5vw, 2rem)' }}>Login to MARKETDRIVE</h2>
            <input type="email" placeholder="Email" style={{ width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', padding: '1rem', borderRadius: '12px', marginBottom: '1rem', fontSize: '1rem' }} />
            <input type="password" placeholder="Password" style={{ width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', padding: '1rem', borderRadius: '12px', marginBottom: '1.5rem', fontSize: '1rem' }} />
            <button onClick={handleLogin} style={{ width: '100%', background: 'linear-gradient(135deg, #1a73e8, #1557b0)', color: '#fff', border: 'none', padding: '1.25rem', borderRadius: '12px', fontWeight: 700, fontSize: '1rem', cursor: 'pointer' }}>Login</button>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPayment && selectedListing && (
        <div onClick={() => setShowPayment(false)} style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.95)', backdropFilter: 'blur(10px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: 'linear-gradient(135deg, #0d0d0d, #1a1a1a)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', padding: '2rem', maxWidth: '500px', width: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 60px rgba(0,0,0,0.5)' }}>
            <h2 style={{ marginBottom: '1.5rem', color: '#1a73e8', fontSize: 'clamp(1.5rem, 5vw, 2rem)' }}>Secure Escrow Payment</h2>
            <div style={{ background: 'rgba(26,115,232,0.1)', border: '1px solid rgba(26,115,232,0.3)', borderRadius: '12px', padding: '1.5rem', marginBottom: '2rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem', color: '#1a73e8', fontWeight: 600 }}>
                <Lock size={20} /> Funds held in escrow until delivery confirmed
              </div>
              <p style={{ color: '#aaa', fontSize: '0.9rem' }}>Your payment is protected. Money is only released to the seller after you confirm receipt of the vehicle.</p>
            </div>
            
            <div style={{ marginBottom: '2rem' }}>
              <h3 style={{ marginBottom: '1rem', color: '#fff' }}>Bank Transfer Details</h3>
              <div style={{ background: 'rgba(255,255,255,0.05)', borderRadius: '12px', padding: '1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem', paddingBottom: '0.75rem', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                  <span style={{ color: '#888' }}>Bank:</span>
                  <span style={{ fontWeight: 600 }}>{BANKING_DETAILS.bank}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem', paddingBottom: '0.75rem', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                  <span style={{ color: '#888' }}>Account Number:</span>
                  <span style={{ fontWeight: 600, color: '#1a73e8', fontFamily: 'monospace', fontSize: '1.1rem' }}>{BANKING_DETAILS.accountNumber}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem', paddingBottom: '0.75rem', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                  <span style={{ color: '#888' }}>Account Holder:</span>
                  <span style={{ fontWeight: 600 }}>{BANKING_DETAILS.accountHolder}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem', paddingBottom: '0.75rem', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                  <span style={{ color: '#888' }}>Reference:</span>
                  <span style={{ fontWeight: 600, color: '#ea4335' }}>ESC-{user?.id}-{selectedListing.id}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: '0.75rem' }}>
                  <span style={{ color: '#888' }}>Amount:</span>
                  <span style={{ fontWeight: 700, fontSize: '1.5rem', color: '#1a73e8' }}>{selectedListing.currency}{selectedListing.price.toLocaleString()}</span>
                </div>
              </div>
            </div>
            
            <button onClick={handlePurchase} style={{ width: '100%', background: 'linear-gradient(135deg, #ea4335, #c5221f)', color: '#fff', border: 'none', padding: '1.25rem', borderRadius: '12px', fontWeight: 700, fontSize: '1rem', cursor: 'pointer' }}>Confirm Purchase</button>
          </div>
        </div>
      )}

      {/* Tracking Modal */}
      {showTracking && (
        <div onClick={() => setShowTracking(false)} style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.95)', backdropFilter: 'blur(10px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: 'linear-gradient(135deg, #0d0d0d, #1a1a1a)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', padding: '2rem', maxWidth: '500px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <h2 style={{ marginBottom: '2rem', color: '#1a73e8', fontSize: 'clamp(1.5rem, 5vw, 2rem)' }}>Order Tracking</h2>
            
            <div style={{ marginBottom: '2rem' }}>
              <div style={{ background: 'rgba(255,255,255,0.05)', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem' }}>{selectedListing?.title}</div>
                <div style={{ color: '#888' }}>Order ID: ESC-{user?.id}-{selectedListing?.id}</div>
              </div>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {[
                  { key: 'in_escrow', label: 'Payment in Escrow', icon: <Lock size={24} />, color: '#1a73e8' },
                  { key: 'shipped', label: 'Vehicle Shipped', icon: <Truck size={24} />, color: '#f9ab00' },
                  { key: 'in_transit', label: 'In Transit', icon: <Truck size={24} />, color: '#f9ab00' },
                  { key: 'delivered', label: 'Delivered', icon: <Shield size={24} />, color: '#34a853' }
                ].map((status) => (
                  <div key={status.key} style={{ display: 'flex', alignItems: 'center', gap: '1rem', padding: '1rem', background: trackingStatus === status.key ? 'rgba(26,115,232,0.1)' : 'rgba(255,255,255,0.03)', border: `1px solid ${trackingStatus === status.key ? 'rgba(26,115,232,0.3)' : 'rgba(255,255,255,0.1)'}`, borderRadius: '12px' }}>
                    <div style={{ color: status.color }}>{status.icon}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, color: trackingStatus === status.key ? status.color : '#fff' }}>{status.label}</div>
                      {trackingStatus === status.key && <div style={{ color: '#888', fontSize: '0.9rem', marginTop: '0.25rem' }}>Current Status</div>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {trackingStatus === 'delivered' && (
              <div style={{ background: 'rgba(52,168,83,0.1)', border: '1px solid rgba(52,168,83,0.3)', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem' }}>
                <h3 style={{ color: '#34a853', marginBottom: '1rem' }}>Vehicle Delivered!</h3>
                <p style={{ color: '#aaa', marginBottom: '1.5rem', fontSize: '0.95rem' }}>Please confirm you've received the vehicle. This will release the payment to the seller.</p>
                <button onClick={() => { alert('Payment released to seller!'); setShowTracking(false) }} style={{ width: '100%', background: 'linear-gradient(135deg, #34a853, #2d8e47)', color: '#fff', border: 'none', padding: '1.25rem', borderRadius: '12px', fontWeight: 700, cursor: 'pointer' }}>Confirm Receipt & Release Payment</button>
              </div>
            )}
            
            <button onClick={() => setShowTracking(false)} style={{ width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', padding: '1rem', borderRadius: '12px', fontWeight: 600, cursor: 'pointer' }}>Close</button>
          </div>
        </div>
      )}

      {/* Post Listing Modal */}
      {showPostListing && (
        <div onClick={() => setShowPostListing(false)} style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.95)', backdropFilter: 'blur(10px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: 'linear-gradient(135deg, #0d0d0d, #1a1a1a)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', padding: '2rem', maxWidth: '500px', width: '100%', maxHeight: '90vh', overflowY: 'auto' }}>
            <h2 style={{ marginBottom: '1.5rem', color: '#1a73e8', fontSize: 'clamp(1.5rem, 5vw, 2rem)' }}>Post a Listing</h2>
            <div style={{ textAlign: 'center', padding: '2rem' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}><FileText size={48} /></div>
              <p style={{ color: '#888', fontSize: 'clamp(0.9rem, 3vw, 1rem)' }}>Complete the 4-step form to post your vehicle with required documents</p>
            </div>
            <button onClick={() => { alert('Listing wizard started!'); setShowPostListing(false) }} style={{ width: '100%', background: 'linear-gradient(135deg, #1a73e8, #1557b0)', color: '#fff', border: 'none', padding: '1.25rem', borderRadius: '12px', fontWeight: 700, cursor: 'pointer', fontSize: 'clamp(0.95rem, 3vw, 1rem)' }}>Start Listing Process</button>
          </div>
        </div>
      )}
    </div>
  )
}

export default App
